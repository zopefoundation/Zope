External Methods


  The External Method product provides support for external Python
  methods, exposing them as callable objects within the Zope 
  environment.
