# BBB
from five.formlib.metaconfigure import EditViewFactory
from five.formlib.metaconfigure import FiveFormDirective
from five.formlib.metaconfigure import EditFormDirective
from five.formlib.metaconfigure import AddViewFactory
from five.formlib.metaconfigure import AddFormDirective
