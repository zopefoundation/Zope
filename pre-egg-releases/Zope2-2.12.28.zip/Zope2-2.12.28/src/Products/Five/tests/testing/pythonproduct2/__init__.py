

def initialize(context):
    print "pythonproduct2 initialized"
