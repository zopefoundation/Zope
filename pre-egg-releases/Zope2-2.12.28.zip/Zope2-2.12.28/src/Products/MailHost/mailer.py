import zope.deferredimport

zope.deferredimport.deprecatedFrom(
    "Import from zope.sendmail instead",
    'zope.sendmail.mailer',
    'SMTPMailer',
    )
