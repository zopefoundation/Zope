# test module, partially private

def priv():
    pass

def pub():
    pass
