
Zope 2.12 specific documentation
================================

.. Note::

    The Zope 2.12.x release series is in security-fix-only mode. It will see
    security fixes until October 2013, the same as Python 2.6.x does.

Contents:

.. toctree::
   :maxdepth: 2

   WHATSNEW.rst
   INSTALL.rst
   INSTALL-buildout.rst
   operation.rst
   USERS.rst
   SECURITY.rst
   SETUID.rst
   SIGNALS.rst
   DEBUGGING.rst
   CHANGES.rst

